#!/usr/bin/env python3
"""
SEC-RAG — Physics-Navigated Retrieval for Local Models
======================================================

Hey Lloyd. This is the entry point. Four modes:

  python run.py eval       — benchmark SEC-RAG vs RAG vs raw model
  python run.py chat       — interactive chat with SEC-RAG
  python run.py continuous — test if SEC-RAG gets smarter over time
  python run.py turbo      — profile model layers (MED depth analysis)

Chat mode commands:
  /method <name>     — switch method (raw, rag, sec_rag)
  /stats             — knowledge graph stats
  /learn <text>      — feed text into the graph
  /save <path>       — persist graph to disk
  /load <path>       — load graph from disk
  /export <path>     — export portable graph (for grafting)
  /import <path>     — import graph from another instance
  /curriculum        — optimal domain learning order
  /confidence <text> — hallucination check (transformers only)
  /quit              — exit

Examples:
  python run.py eval --model Qwen/Qwen2.5-0.5B
  python run.py eval --model /mnt/models/qwen-122b-q4.gguf
  python run.py chat --model Qwen/Qwen2.5-0.5B --corpus corpus/my_docs.txt
  python run.py chat --model /mnt/models/qwen-122b-q4.gguf --corpus-dir /data/docs/
  python run.py continuous --model Qwen/Qwen2.5-0.5B
"""

import argparse
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

from engine import SECRAGPipeline, KnowledgeGraph, EmbeddingIndex
from server import LocalModelServer
from turbo import MEDProfiler, MEDTurboWrapper
from safety import HallucinationDetector
from questions import KNOWLEDGE_CORPUS, FACTUAL_QA, score_answer


def load_corpus_from_file(path: str) -> dict[str, str]:
    """Load corpus from a text file. Returns {filename: content}."""
    p = Path(path)
    if not p.exists():
        print(f"Error: corpus file not found: {path}")
        sys.exit(1)
    return {p.stem: p.read_text(encoding="utf-8")}


def load_corpus_from_dir(path: str) -> dict[str, str]:
    """Load corpus from a directory of text files. Each file = one domain."""
    p = Path(path)
    if not p.is_dir():
        print(f"Error: corpus directory not found: {path}")
        sys.exit(1)
    corpus = {}
    for f in sorted(p.glob("*.txt")):
        corpus[f.stem] = f.read_text(encoding="utf-8")
    if not corpus:
        print(f"Error: no .txt files found in {path}")
        sys.exit(1)
    print(f"Loaded {len(corpus)} corpus files from {path}")
    return corpus


# ─── Eval Mode ───

def cmd_eval(args):
    """Benchmark: Raw LLM vs RAG vs SEC-RAG on 70 factual questions."""
    questions = FACTUAL_QA
    if args.quick:
        by_topic = defaultdict(list)
        for q in questions:
            by_topic[q["topic"]].append(q)
        questions = []
        for topic, qs in by_topic.items():
            questions.extend(qs[:3])

    n_questions = len(questions)
    n_samples = args.samples

    server = LocalModelServer(args.model, n_gpu_layers=args.gpu_layers)
    pipeline = SECRAGPipeline(server)

    print(f"\n{'=' * 72}")
    print(f"SEC-RAG EVAL: Raw vs RAG vs SEC-RAG")
    print(f"{'=' * 72}")
    print(f"Model: {args.model}")
    print(f"Questions: {n_questions}, Samples: {n_samples}")
    print(f"Total generations: {n_questions * n_samples * 3}\n")

    # Use built-in corpus or custom
    if args.corpus:
        corpus = load_corpus_from_file(args.corpus)
    elif args.corpus_dir:
        corpus = load_corpus_from_dir(args.corpus_dir)
    else:
        corpus = KNOWLEDGE_CORPUS

    full_corpus = "\n".join(corpus.values())
    print("Ingesting corpus...")
    pipeline.ingest(full_corpus, n_passes=5)

    methods = ["raw", "rag", "sec_rag"]
    results = {m: defaultdict(lambda: {"correct": 0, "total": 0}) for m in methods}
    overall = {m: {"correct": 0, "total": 0} for m in methods}

    print(f"\n{'Question':<48} {'Raw':>5} {'RAG':>5} {'S-R':>5}")
    print(f"{'-' * 68}")

    for qi, qa in enumerate(questions):
        q_scores = {}
        for method in methods:
            correct_count = 0
            for _ in range(n_samples):
                output = pipeline.query(qa["query"], method=method)
                is_correct, _ = score_answer(output, qa["correct"], qa["wrong"])
                if is_correct:
                    correct_count += 1
            acc = correct_count / n_samples
            q_scores[method] = acc
            results[method][qa["topic"]]["correct"] += correct_count
            results[method][qa["topic"]]["total"] += n_samples
            overall[method]["correct"] += correct_count
            overall[method]["total"] += n_samples

        best = max(q_scores.values())
        cols = []
        for m in methods:
            s = f"{q_scores[m]:.0%}"
            if q_scores[m] == best and best > 0:
                s += "*"
            cols.append(f"{s:>5}")
        print(f"  [{qi+1:2d}/{n_questions}] {qa['query']:<44} {' '.join(cols)}")

    # Summary
    print(f"\n{'=' * 72}")
    print("RESULTS BY DOMAIN")
    print(f"{'=' * 72}")
    print(f"  {'Domain':<15} {'Raw':>5} {'RAG':>5} {'S-R':>5}")
    print(f"  {'-' * 35}")

    topics = sorted(set(q["topic"] for q in questions))
    for topic in topics:
        cols = []
        for m in methods:
            r = results[m][topic]
            acc = r["correct"] / r["total"] if r["total"] > 0 else 0
            cols.append(f"{acc:>5.0%}")
        print(f"  {topic:<15} {' '.join(cols)}")

    print(f"  {'-' * 35}")
    cols = []
    for m in methods:
        acc = overall[m]["correct"] / overall[m]["total"] if overall[m]["total"] > 0 else 0
        cols.append(f"{acc:>5.0%}")
    print(f"  {'OVERALL':<15} {' '.join(cols)}")

    stats = pipeline.graph.stats()
    print(f"\n  Knowledge graph: {stats['concepts']} concepts, "
          f"{stats['relations']} relations, {stats['crystallized']} crystallized")

    raw_acc = overall["raw"]["correct"] / overall["raw"]["total"]
    rag_acc = overall["rag"]["correct"] / overall["rag"]["total"]
    sr_acc = overall["sec_rag"]["correct"] / overall["sec_rag"]["total"]
    print(f"\n  SEC-RAG vs Raw: {sr_acc - raw_acc:+.0%}")
    print(f"  SEC-RAG vs RAG: {sr_acc - rag_acc:+.0%}")

    # Save
    results_dir = Path(__file__).parent / "results"
    results_dir.mkdir(exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    model_slug = Path(args.model).stem.replace("/", "_")
    results_file = results_dir / f"eval_{model_slug}_{timestamp}.json"
    results_data = {
        "model_id": args.model, "timestamp": timestamp,
        "n_questions": n_questions, "n_samples": n_samples,
        "overall": {m: overall[m]["correct"] / overall[m]["total"] for m in methods},
        "per_domain": {
            topic: {m: results[m][topic]["correct"] / results[m][topic]["total"]
                    if results[m][topic]["total"] > 0 else 0 for m in methods}
            for topic in topics
        },
        "graph_stats": stats,
    }
    with open(results_file, "w") as f:
        json.dump(results_data, f, indent=2)
    print(f"\n  Results saved: {results_file}")


# ─── Chat Mode ───

def cmd_chat(args):
    """Interactive SEC-RAG chat. Feed it a corpus, ask questions."""
    server = LocalModelServer(args.model, n_gpu_layers=args.gpu_layers)
    pipeline = SECRAGPipeline(server)

    # Load corpus
    if args.corpus:
        corpus = load_corpus_from_file(args.corpus)
    elif args.corpus_dir:
        corpus = load_corpus_from_dir(args.corpus_dir)
    else:
        print("No corpus specified. Using built-in science corpus.")
        print("Tip: use --corpus file.txt or --corpus-dir /path/ for your own data.\n")
        corpus = KNOWLEDGE_CORPUS

    full_corpus = "\n".join(corpus.values())
    print("\nIngesting corpus...")
    pipeline.ingest(full_corpus, n_passes=5)

    # Initialize hallucination detector if using transformers backend
    detector = None
    if server.backend == "transformers":
        detector = HallucinationDetector(server)

    stats = pipeline.graph.stats()
    print(f"\nReady. Graph: {stats['concepts']} concepts, "
          f"{stats['relations']} relations, {stats['crystallized']} crystallized")
    print(f"Methods: sec_rag (default), rag, raw")
    print(f"Commands:")
    print(f"  /method <name>     — switch retrieval method (raw, rag, sec_rag)")
    print(f"  /stats             — show knowledge graph stats")
    print(f"  /learn <text>      — feed text into the knowledge graph")
    print(f"  /save <path>       — save knowledge graph to file")
    print(f"  /load <path>       — load knowledge graph from file")
    print(f"  /export <path>     — export portable graph (for grafting to another model)")
    print(f"  /import <path>     — import portable graph from another SEC-RAG instance")
    print(f"  /curriculum        — analyze optimal domain learning order")
    print(f"  /confidence <text> — check text for hallucination signals")
    print(f"  /quit              — exit\n")

    method = "sec_rag"
    query_count = 0

    while True:
        try:
            user_input = input(f"[{method}] > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye.")
            break

        if not user_input:
            continue

        if user_input == "/quit":
            print("Bye.")
            break

        if user_input.startswith("/method "):
            new_method = user_input.split(" ", 1)[1].strip()
            if new_method in ("raw", "rag", "sec_rag"):
                method = new_method
                print(f"  Switched to: {method}")
            else:
                print(f"  Unknown method: {new_method}. Use raw, rag, or sec_rag.")
            continue

        if user_input == "/stats":
            stats = pipeline.graph.stats()
            print(f"  Concepts: {stats['concepts']}")
            print(f"  Relations: {stats['relations']}")
            print(f"  Crystallized: {stats['crystallized']}")
            print(f"  Ordered: {stats['ordered']}")
            print(f"  Transitional: {stats['transitional']}")
            print(f"  Chaotic: {stats['chaotic']}")
            print(f"  Queries answered: {query_count}")
            continue

        if user_input.startswith("/learn "):
            text = user_input.split(" ", 1)[1]
            pipeline.graph.learn(text)
            stats = pipeline.graph.stats()
            print(f"  Learned. Graph: {stats['concepts']} concepts, "
                  f"{stats['crystallized']} crystallized")
            continue

        if user_input.startswith("/save "):
            save_path = user_input.split(" ", 1)[1].strip()
            pipeline.graph.save(save_path)
            continue

        if user_input.startswith("/load "):
            load_path = user_input.split(" ", 1)[1].strip()
            try:
                pipeline.graph = KnowledgeGraph.load(load_path)
                stats = pipeline.graph.stats()
                print(f"  Graph loaded. {stats['concepts']} concepts, "
                      f"{stats['crystallized']} crystallized")
            except FileNotFoundError:
                print(f"  File not found: {load_path}")
            continue

        if user_input.startswith("/export "):
            export_path = user_input.split(" ", 1)[1].strip()
            data = pipeline.graph.export_portable()
            with open(export_path, "w") as f:
                json.dump(data, f, indent=2)
            print(f"  Exported portable graph: {export_path}")
            print(f"  ({data['stats']['concepts']} concepts, "
                  f"{len(data['relations'])} relations)")
            continue

        if user_input.startswith("/import "):
            import_path = user_input.split(" ", 1)[1].strip()
            try:
                with open(import_path) as f:
                    data = json.load(f)
                pipeline.graph.import_portable(data)
                stats = pipeline.graph.stats()
                print(f"  Graph after graft: {stats['concepts']} concepts, "
                      f"{stats['crystallized']} crystallized")
            except FileNotFoundError:
                print(f"  File not found: {import_path}")
            except ValueError as e:
                print(f"  Error: {e}")
            continue

        if user_input == "/curriculum":
            if not corpus:
                print("  Need corpus data for curriculum analysis.")
                continue
            print("  Analyzing domain transfer...")
            result = pipeline.graph.analyze_transfer(corpus)
            print(f"\n  Recommended learning order:")
            for i, domain in enumerate(result["recommended_order"]):
                score = result["domain_scores"][domain]
                hub = result["hub_scores"][domain]
                bridges = result["relational_bridges"][domain]
                print(f"    {i+1}. {domain:<15} score={score:.3f}  "
                      f"(hub={hub:.3f}, bridges={bridges})")
            print(f"\n  Transfer matrix:")
            domains = result["recommended_order"]
            header = f"  {'':>12}" + "".join(f"{d[:8]:>9}" for d in domains)
            print(header)
            for src in domains:
                row = f"  {src:>12}"
                for dst in domains:
                    val = result["transfer_matrix"][src].get(dst, 0)
                    row += f"{val:>9.3f}"
                print(row)
            continue

        if user_input.startswith("/confidence "):
            text = user_input.split(" ", 1)[1].strip()
            if detector is None:
                print("  Hallucination detection requires transformers backend (not GGUF).")
                print("  GGUF models don't expose hidden states needed for PAC analysis.")
                continue
            print("  Analyzing PAC conservation...")
            result = detector.check(text)
            print(f"  Confidence: {result['confidence']:.1%}")
            print(f"  Budget return: {result['budget_return']}")
            print(f"  Verdict: {result['verdict']}")
            pac = result["pac_summary"]
            if pac.get("n_layers"):
                print(f"  Layers analyzed: {pac['n_layers']}")
                print(f"  Mean pressure: {pac['mean_pressure']}")
                print(f"  Pressure std: {pac['pressure_std']}")
                print(f"  Mean action: {pac['mean_action']}")
            continue

        # Generate response
        t0 = time.time()
        response = pipeline.query(user_input, method=method, max_tokens=args.max_tokens)
        elapsed = time.time() - t0

        print(f"\n  {response.strip()}")
        print(f"  [{elapsed:.1f}s, method={method}]\n")

        # Continuous learning: learn from the exchange
        pipeline.learn_from_query(user_input, response)
        query_count += 1


# ─── Continuous Learning Mode ───

def cmd_continuous(args):
    """Test if SEC-RAG compounds over time by feeding domains incrementally."""
    questions = FACTUAL_QA
    n_samples = args.samples
    domain_order = list(KNOWLEDGE_CORPUS.keys())

    server = LocalModelServer(args.model, n_gpu_layers=args.gpu_layers)

    print(f"\n{'=' * 72}")
    print("CONTINUOUS LEARNING: DOES SEC-RAG COMPOUND?")
    print(f"{'=' * 72}")
    print(f"Model: {args.model}")
    print(f"Questions: {len(questions)}, Samples: {n_samples}")
    print(f"Domain order: {' -> '.join(domain_order)}")

    full_corpus = "\n".join(KNOWLEDGE_CORPUS.values())
    rag_index = EmbeddingIndex()
    rag_index.index(full_corpus)

    graph = KnowledgeGraph(window=5)
    methods = ["rag", "sec_rag"]
    learning_curve = []

    for step, domain in enumerate(domain_order):
        print(f"\n{'=' * 72}")
        print(f"STEP {step+1}/{len(domain_order)}: Learn '{domain}' "
              f"({len(KNOWLEDGE_CORPUS[domain])} chars)")
        print(f"{'=' * 72}")

        for _ in range(5):
            graph.learn(KNOWLEDGE_CORPUS[domain])

        stats = graph.stats()
        print(f"  Graph: {stats['concepts']} concepts, {stats['relations']} relations, "
              f"{stats['crystallized']} crystallized")

        step_results = {m: {"correct": 0, "total": 0} for m in methods}
        step_domain = {m: defaultdict(lambda: {"correct": 0, "total": 0}) for m in methods}

        for qa in questions:
            for method in methods:
                correct_count = 0
                for _ in range(n_samples):
                    if method == "rag":
                        retrieved = rag_index.retrieve(qa["query"], top_k=3)
                        context = ". ".join(s for s, _ in retrieved) + "."
                        prompt = f"Based on the following information: {context}\n\n{qa['query']}"
                    else:
                        rel_context = graph.format_relational_context(qa["query"])
                        phase = graph.dominant_phase(qa["query"])
                        candidates = rag_index.retrieve(qa["query"], top_k=6)
                        reranked = graph.sec_rerank(candidates)
                        n_ret = 2 if phase == "crystallized" else (3 if phase in ("ordered", "unknown") else 4)
                        top_sents = [s for s, _ in reranked[:n_ret]]
                        parts = []
                        if rel_context:
                            parts.append(f"Known facts: {rel_context}")
                        if top_sents:
                            parts.append(f"Reference: {'. '.join(top_sents)}")
                        context = ". ".join(parts) + "." if parts else ""
                        prompt = f"{context}\n\n{qa['query']}" if context else qa["query"]

                    result = server.generate(prompt, max_tokens=40, temperature=0.7)
                    is_correct, _ = score_answer(result.text, qa["correct"], qa["wrong"])
                    if is_correct:
                        correct_count += 1

                step_results[method]["correct"] += correct_count
                step_results[method]["total"] += n_samples
                step_domain[method][qa["topic"]]["correct"] += correct_count
                step_domain[method][qa["topic"]]["total"] += n_samples

        for m in methods:
            acc = step_results[m]["correct"] / step_results[m]["total"]
            in_r = step_domain[m][domain]
            in_acc = in_r["correct"] / in_r["total"] if in_r["total"] > 0 else 0
            print(f"  {m:>8}  {acc:.0%} overall  ({in_acc:.0%} in-domain)")

        learning_curve.append({
            "step": step + 1, "domain": domain, "graph_stats": stats,
            "results": {m: step_results[m]["correct"] / step_results[m]["total"]
                        for m in methods},
        })

    # Summary
    print(f"\n{'=' * 72}")
    print("LEARNING CURVE")
    print(f"{'=' * 72}")
    print(f"  {'Step':<6} {'Domain':<15} {'RAG':>5} {'S-R':>5} {'Delta':>6} {'Concepts':>9}")
    print(f"  {'-' * 50}")
    for entry in learning_curve:
        rag_acc = entry["results"]["rag"]
        sr_acc = entry["results"]["sec_rag"]
        delta = sr_acc - rag_acc
        n_concepts = entry["graph_stats"]["concepts"]
        print(f"  {entry['step']:<6} {entry['domain']:<15} {rag_acc:>5.0%} "
              f"{sr_acc:>5.0%} {delta:>+5.0%} {n_concepts:>9}")

    results_dir = Path(__file__).parent / "results"
    results_dir.mkdir(exist_ok=True)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    model_slug = Path(args.model).stem.replace("/", "_")
    results_file = results_dir / f"continuous_{model_slug}_{timestamp}.json"
    with open(results_file, "w") as f:
        json.dump({"model_id": args.model, "learning_curve": learning_curve}, f, indent=2)
    print(f"\n  Results saved: {results_file}")


# ─── Turbo Mode ───

def cmd_turbo(args):
    """Profile model layers and optionally benchmark MED layer skipping."""
    server = LocalModelServer(args.model, n_gpu_layers=args.gpu_layers)

    if server.backend != "transformers":
        print("Error: MED Turbo requires transformers backend (not GGUF).")
        print("GGUF models use llama.cpp which handles layer optimization internally.")
        sys.exit(1)

    profiler = MEDProfiler(server, threshold=args.threshold)
    print(f"\nProfiling {args.model}...")
    profile = profiler.profile()
    print(f"\n{profile}")

    if args.benchmark:
        turbo = MEDTurboWrapper(server, profile)
        turbo.benchmark(n_runs=args.runs)


# ─── CLI ───

def main():
    parser = argparse.ArgumentParser(
        description="SEC-RAG: Physics-Navigated Retrieval for Local Models",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run.py eval --model Qwen/Qwen2.5-0.5B
  python run.py eval --model /path/to/model.gguf --quick
  python run.py chat --model Qwen/Qwen2.5-0.5B --corpus my_docs.txt
  python run.py chat --model /path/to/model.gguf --corpus-dir /data/docs/
  python run.py continuous --model Qwen/Qwen2.5-0.5B --samples 3
        """,
    )
    subparsers = parser.add_subparsers(dest="command", help="Mode")

    # Shared args
    def add_common_args(p):
        p.add_argument("--model", default="Qwen/Qwen2.5-0.5B",
                        help="HuggingFace model ID or GGUF path")
        p.add_argument("--gpu-layers", type=int, default=-1,
                        help="GPU layers for llama.cpp (-1 = all)")

    # Eval
    p_eval = subparsers.add_parser("eval", help="Benchmark SEC-RAG vs RAG vs raw")
    add_common_args(p_eval)
    p_eval.add_argument("--samples", type=int, default=2, help="Samples per question")
    p_eval.add_argument("--quick", action="store_true", help="24 questions only")
    p_eval.add_argument("--corpus", help="Custom corpus file (.txt)")
    p_eval.add_argument("--corpus-dir", help="Directory of .txt corpus files")

    # Chat
    p_chat = subparsers.add_parser("chat", help="Interactive SEC-RAG chat")
    add_common_args(p_chat)
    p_chat.add_argument("--corpus", help="Corpus file (.txt)")
    p_chat.add_argument("--corpus-dir", help="Directory of .txt corpus files")
    p_chat.add_argument("--max-tokens", type=int, default=120, help="Max tokens per response")

    # Continuous
    p_cont = subparsers.add_parser("continuous", help="Test learning curve over time")
    add_common_args(p_cont)
    p_cont.add_argument("--samples", type=int, default=2, help="Samples per question")

    # Turbo
    p_turbo = subparsers.add_parser("turbo", help="Profile layers + MED speed boost")
    add_common_args(p_turbo)
    p_turbo.add_argument("--benchmark", action="store_true", help="Run speed benchmark")
    p_turbo.add_argument("--threshold", type=float, default=0.1,
                          help="Layer contribution threshold (default: 0.1)")
    p_turbo.add_argument("--runs", type=int, default=5, help="Benchmark runs")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "eval":
        cmd_eval(args)
    elif args.command == "chat":
        cmd_chat(args)
    elif args.command == "continuous":
        cmd_continuous(args)
    elif args.command == "turbo":
        cmd_turbo(args)


if __name__ == "__main__":
    main()
