"""
PAC Conservation Monitor — Hallucination Detection
====================================================

Detects hallucinations by measuring PAC (Pressure-Action-Curvature) conservation
violations in transformer hidden states. Based on TinyCIMM-Boltzmann findings:

  - Factual text: PAC budget return ~0.98 (energy conserved across layers)
  - Hallucinated text: +9.6% uncompensated entropy (conservation violated)

The idea: when a model "knows" something, its internal representations stay
coherent across layers (energy in ≈ energy out). When it's making stuff up,
entropy leaks — the hidden states diverge from conservation.

Requires transformers backend (not GGUF) for hidden state access.
"""

import numpy as np


# ─── DFT Constants ───

XI_SEC = 0.0618       # Structural coupling constant
LAMBDA_STAR = 0.9816  # Optimal conservation threshold
BUDGET_THRESHOLD = 0.98  # Budget return ratio below this = potential hallucination


def compute_pac_components(hidden_states: list) -> dict:
    """Compute PAC (Pressure-Action-Curvature) from hidden state sequence.

    For each layer transition, measures:
      - Pressure (P): magnitude change (||h_out|| / ||h_in||)
      - Action (A): directional change (1 - cosine_similarity)
      - Curvature (C): rate of change of action (second derivative)

    Returns per-layer and aggregate PAC metrics.
    """
    if not hidden_states or len(hidden_states) < 3:
        return {"valid": False, "reason": "Need at least 3 layers for PAC"}

    layers = []
    for h in hidden_states:
        if hasattr(h, 'detach'):
            arr = h.detach().cpu().numpy()
        else:
            arr = np.array(h)
        # Flatten to 1D (take last token if sequence)
        if arr.ndim > 1:
            arr = arr[-1] if arr.ndim == 2 else arr[0, -1]
        layers.append(arr.astype(np.float64))

    n_layers = len(layers)
    pressures = []
    actions = []

    for i in range(1, n_layers):
        h_in = layers[i - 1]
        h_out = layers[i]

        # Pressure: magnitude ratio
        norm_in = np.linalg.norm(h_in)
        norm_out = np.linalg.norm(h_out)
        p = norm_out / norm_in if norm_in > 1e-10 else 1.0
        pressures.append(p)

        # Action: directional change
        cos_sim = np.dot(h_in, h_out) / (norm_in * norm_out + 1e-10)
        cos_sim = np.clip(cos_sim, -1.0, 1.0)
        a = 1.0 - cos_sim
        actions.append(a)

    # Curvature: second derivative of action
    curvatures = []
    for i in range(1, len(actions)):
        c = abs(actions[i] - actions[i - 1])
        curvatures.append(c)

    return {
        "valid": True,
        "n_layers": n_layers,
        "pressures": pressures,
        "actions": actions,
        "curvatures": curvatures,
    }


def compute_budget_return(pac: dict) -> float:
    """Compute the PAC budget return ratio.

    Budget return = (energy at last layer) / (energy at first layer).
    Perfect conservation = 1.0. Hallucination leaks energy.

    From si_regulate: factual text averages ~0.988, hallucinated ~0.92.
    """
    if not pac.get("valid"):
        return 1.0  # Can't measure, assume okay

    pressures = pac["pressures"]
    if not pressures:
        return 1.0

    # Budget return is the product of all pressure ratios
    # (how much energy survives from first to last layer)
    budget = 1.0
    for p in pressures:
        budget *= p

    # Normalize: perfect conservation = 1.0
    # Values < 1.0 = energy lost (compression)
    # Values > 1.0 = energy gained (expansion/hallucination)
    return budget


def compute_conservation_score(pac: dict) -> float:
    """Compute a 0-1 conservation score. Higher = more conserved = more trustworthy.

    Combines three signals:
      1. Budget return closeness to 1.0
      2. Pressure stability (low variance = conserved)
      3. Action smoothness (low curvature = coherent)
    """
    if not pac.get("valid"):
        return 0.5  # Unknown

    pressures = pac["pressures"]
    actions = pac["actions"]
    curvatures = pac["curvatures"]

    # 1. Budget return (closeness to 1.0)
    budget = compute_budget_return(pac)
    budget_score = max(0, 1.0 - abs(1.0 - budget) * 5)

    # 2. Pressure stability (low variance)
    if pressures:
        p_std = np.std(pressures)
        pressure_score = max(0, 1.0 - p_std * 10)
    else:
        pressure_score = 0.5

    # 3. Action smoothness (low curvature)
    if curvatures:
        mean_curv = np.mean(curvatures)
        smooth_score = max(0, 1.0 - mean_curv * 20)
    else:
        smooth_score = 0.5

    # Weighted combination
    score = budget_score * 0.5 + pressure_score * 0.3 + smooth_score * 0.2
    return round(min(1.0, max(0.0, score)), 3)


class HallucinationDetector:
    """Detects hallucinations using PAC conservation analysis.

    Usage:
        detector = HallucinationDetector(server)
        result = detector.check("The Earth orbits the Moon.")
        print(result["confidence"])   # 0.0-1.0 (higher = more trustworthy)
        print(result["verdict"])      # "likely_factual" or "potential_hallucination"

    Requires transformers backend for hidden state access.
    """

    def __init__(self, server, threshold: float = BUDGET_THRESHOLD):
        self.server = server
        self.threshold = threshold

        if server.backend != "transformers":
            raise ValueError(
                "HallucinationDetector requires transformers backend for hidden state access. "
                "GGUF models don't expose layer-by-layer hidden states."
            )

    def check(self, text: str) -> dict:
        """Analyze text for hallucination signals.

        Returns:
            {
                "text": str,
                "confidence": float,      # 0-1, higher = more trustworthy
                "budget_return": float,    # ~1.0 = conserved, >1.05 = suspicious
                "verdict": str,            # "likely_factual" / "uncertain" / "potential_hallucination"
                "pac_summary": dict,       # Layer-by-layer PAC stats
            }
        """
        # Generate with hidden states
        result = self.server.generate(
            text,
            max_tokens=1,  # We just need the hidden states from encoding
            temperature=0.0,
            return_hidden_states=True,
        )

        hidden_states = result.hidden_states
        if hidden_states is None:
            return {
                "text": text,
                "confidence": 0.5,
                "budget_return": None,
                "verdict": "unknown",
                "pac_summary": {"error": "No hidden states available"},
            }

        pac = compute_pac_components(hidden_states)
        budget = compute_budget_return(pac)
        confidence = compute_conservation_score(pac)

        # Verdict
        if confidence > 0.8:
            verdict = "likely_factual"
        elif confidence > 0.5:
            verdict = "uncertain"
        else:
            verdict = "potential_hallucination"

        # PAC summary for display
        pac_summary = {
            "n_layers": pac.get("n_layers", 0),
            "mean_pressure": round(np.mean(pac["pressures"]), 4) if pac.get("pressures") else None,
            "pressure_std": round(np.std(pac["pressures"]), 4) if pac.get("pressures") else None,
            "mean_action": round(np.mean(pac["actions"]), 4) if pac.get("actions") else None,
            "mean_curvature": round(np.mean(pac["curvatures"]), 4) if pac.get("curvatures") else None,
        }

        return {
            "text": text,
            "confidence": confidence,
            "budget_return": round(budget, 4),
            "verdict": verdict,
            "pac_summary": pac_summary,
        }

    def check_response(self, question: str, response: str) -> dict:
        """Check a question-response pair. Analyzes the response in context."""
        full_text = f"Question: {question}\nAnswer: {response}"
        result = self.check(full_text)
        result["question"] = question
        result["response"] = response
        return result
