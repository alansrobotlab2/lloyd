"""
Eval questions — 70 factual questions across 8 science domains.

Used for benchmarking SEC-RAG vs RAG vs raw model output.
Each question has correct answers (must appear) and wrong answers (must not appear).
"""

KNOWLEDGE_CORPUS = {
    "evolution": (
        "Charles Darwin proposed the theory of evolution by natural selection. Darwin traveled on "
        "the HMS Beagle to the Galapagos Islands where he observed finch beak variations. Alfred "
        "Russel Wallace independently discovered natural selection while studying wildlife in the "
        "Malay Archipelago. Darwin published On the Origin of Species in 1859. Lamarck proposed "
        "an earlier theory of inheritance of acquired characteristics which was later disproved. "
        "Natural selection acts on heritable variation within populations. Speciation occurs when "
        "populations become reproductively isolated."
    ),
    "genetics": (
        "Gregor Mendel discovered the laws of inheritance through pea plant experiments in 1866. "
        "Mendel is known as the father of genetics. DNA carries genetic instructions for all living "
        "organisms. James Watson and Francis Crick discovered the double helix structure of DNA in "
        "1953. Rosalind Franklin produced the X-ray crystallography images crucial for discovering "
        "DNA structure. Barbara McClintock discovered transposable elements (jumping genes) in maize. "
        "The Human Genome Project completed sequencing the human genome in 2003. CRISPR-Cas9 is "
        "used for precise gene editing and was developed by Jennifer Doudna and Emmanuelle Charpentier."
    ),
    "neuroscience": (
        "The human brain contains approximately 86 billion neurons. The prefrontal cortex is essential "
        "for planning and decision making. The hippocampus is essential for memory formation and spatial "
        "navigation. Santiago Ramon y Cajal discovered that neurons are individual cells, establishing "
        "the neuron doctrine. Neurons communicate through synaptic connections using neurotransmitters. "
        "Broca discovered that damage to a specific left frontal region causes speech production deficits. "
        "Wernicke discovered that damage to the left temporal region causes language comprehension deficits. "
        "Dopamine is essential for reward processing and motivation. Serotonin regulates mood and sleep."
    ),
    "physics": (
        "Isaac Newton proposed the laws of motion and universal gravitation. Newton published Principia "
        "Mathematica in 1687. Albert Einstein proposed the theory of general relativity in 1915 and "
        "special relativity in 1905. Einstein proposed the photoelectric effect which demonstrated "
        "the particle nature of light. Max Planck introduced the quantum hypothesis in 1900. Niels "
        "Bohr proposed the atomic model with quantized electron orbits. Werner Heisenberg formulated "
        "the uncertainty principle. Erwin Schrodinger developed the wave equation for quantum mechanics. "
        "Marie Curie discovered radioactivity in polonium and radium."
    ),
    "chemistry": (
        "Dmitri Mendeleev created the periodic table of elements in 1869, organizing elements by "
        "atomic weight and predicting undiscovered elements. Antoine Lavoisier is known as the father "
        "of modern chemistry and discovered the role of oxygen in combustion. John Dalton proposed "
        "the modern atomic theory in 1803. Linus Pauling discovered the nature of chemical bonds "
        "and proposed electronegativity scales. The pH scale measures hydrogen ion concentration. "
        "Water consists of two hydrogen atoms and one oxygen atom. Acids have pH below 7 and bases "
        "have pH above 7."
    ),
    "cell_biology": (
        "The mitochondria is known as the powerhouse of the cell. ATP is the energy currency of cells. "
        "Cellular respiration converts glucose into ATP through glycolysis, the Krebs cycle, and "
        "oxidative phosphorylation. Photosynthesis converts sunlight into chemical energy in plants. "
        "Chloroplasts contain chlorophyll which absorbs light. Robert Hooke discovered cells in 1665 "
        "using a microscope. The cell membrane consists of a phospholipid bilayer. Ribosomes are "
        "responsible for protein synthesis. The endoplasmic reticulum is essential for protein folding "
        "and lipid synthesis."
    ),
    "ml": (
        "Machine learning uses algorithms that learn from data without explicit programming. Neural "
        "networks are inspired by biological neurons. Geoffrey Hinton developed backpropagation for "
        "training neural networks. Transformers use self-attention mechanisms and were introduced in "
        "the paper Attention Is All You Need. Attention was proposed by Vaswani in 2017. Deep learning "
        "uses many layers of neural networks. Yann LeCun developed convolutional neural networks for "
        "image recognition. Ian Goodfellow invented generative adversarial networks in 2014. Support "
        "vector machines use kernel functions for classification in high-dimensional spaces."
    ),
    "astronomy": (
        "Galileo Galilei discovered the moons of Jupiter using a telescope in 1610. Johannes Kepler "
        "formulated the three laws of planetary motion. Edwin Hubble discovered that the universe is "
        "expanding in 1929. The Big Bang theory describes the origin of the universe approximately "
        "13.8 billion years ago. Black holes are regions where gravity is so strong that nothing can "
        "escape. Stephen Hawking proposed that black holes emit radiation through quantum effects. "
        "The speed of light in vacuum is approximately 299792458 meters per second. Neutron stars "
        "are the densest known objects in the universe after black holes."
    ),
}


FACTUAL_QA = [
    # Evolution (8)
    {"query": "Darwin proposed", "correct": ["natural selection", "evolution"], "wrong": ["relativity", "quantum"], "topic": "evolution"},
    {"query": "Wallace independently discovered", "correct": ["natural selection"], "wrong": ["dna", "gravity"], "topic": "evolution"},
    {"query": "The Origin of Species was published in", "correct": ["1859"], "wrong": ["1687", "1905", "1953"], "topic": "evolution"},
    {"query": "Darwin traveled on the", "correct": ["beagle"], "wrong": ["enterprise", "mayflower"], "topic": "evolution"},
    {"query": "Lamarck proposed", "correct": ["inheritance", "acquired characteristics"], "wrong": ["natural selection", "relativity"], "topic": "evolution"},
    {"query": "Speciation occurs when populations become", "correct": ["reproductively isolated", "isolated"], "wrong": ["larger", "extinct"], "topic": "evolution"},
    {"query": "Darwin observed finch beak variations in the", "correct": ["galapagos"], "wrong": ["amazon", "arctic"], "topic": "evolution"},
    {"query": "Wallace studied wildlife in the", "correct": ["malay", "archipelago"], "wrong": ["galapagos", "amazon"], "topic": "evolution"},

    # Genetics (9)
    {"query": "Mendel is known as the father of", "correct": ["genetics"], "wrong": ["physics", "chemistry"], "topic": "genetics"},
    {"query": "Watson and Crick discovered the structure of", "correct": ["dna"], "wrong": ["rna", "protein"], "topic": "genetics"},
    {"query": "Rosalind Franklin produced", "correct": ["x-ray", "crystallography"], "wrong": ["evolution", "gravity"], "topic": "genetics"},
    {"query": "Mendel discovered the laws of inheritance through", "correct": ["pea"], "wrong": ["fruit flies", "mice"], "topic": "genetics"},
    {"query": "The Human Genome Project completed sequencing in", "correct": ["2003"], "wrong": ["1990", "2010", "1953"], "topic": "genetics"},
    {"query": "CRISPR-Cas9 was developed by", "correct": ["doudna", "charpentier"], "wrong": ["watson", "crick"], "topic": "genetics"},
    {"query": "McClintock discovered", "correct": ["transposable", "jumping genes"], "wrong": ["dna", "rna"], "topic": "genetics"},
    {"query": "DNA carries genetic instructions for", "correct": ["living organisms", "organisms", "living"], "wrong": ["minerals", "rocks"], "topic": "genetics"},
    {"query": "The double helix structure was discovered in", "correct": ["1953"], "wrong": ["1866", "2003"], "topic": "genetics"},

    # Neuroscience (9)
    {"query": "The hippocampus is essential for", "correct": ["memory"], "wrong": ["vision", "hearing"], "topic": "neuroscience"},
    {"query": "The prefrontal cortex handles", "correct": ["planning", "decision"], "wrong": ["vision", "breathing"], "topic": "neuroscience"},
    {"query": "Ramon y Cajal discovered that neurons are", "correct": ["individual", "cells"], "wrong": ["connected", "continuous"], "topic": "neuroscience"},
    {"query": "Broca discovered that damage to the left frontal region causes", "correct": ["speech"], "wrong": ["blindness", "deafness"], "topic": "neuroscience"},
    {"query": "Wernicke discovered that damage to the left temporal region causes", "correct": ["comprehension", "language"], "wrong": ["blindness", "paralysis"], "topic": "neuroscience"},
    {"query": "Dopamine is essential for", "correct": ["reward", "motivation"], "wrong": ["digestion", "breathing"], "topic": "neuroscience"},
    {"query": "Serotonin regulates", "correct": ["mood", "sleep"], "wrong": ["vision", "hearing"], "topic": "neuroscience"},
    {"query": "The human brain contains approximately", "correct": ["86 billion", "86", "billion"], "wrong": ["million", "trillion"], "topic": "neuroscience"},
    {"query": "Neurons communicate through synaptic connections using", "correct": ["neurotransmitters"], "wrong": ["electricity", "light"], "topic": "neuroscience"},

    # Physics (9)
    {"query": "Newton published Principia Mathematica in", "correct": ["1687"], "wrong": ["1859", "1905"], "topic": "physics"},
    {"query": "Einstein proposed general relativity in", "correct": ["1915"], "wrong": ["1687", "1859"], "topic": "physics"},
    {"query": "Einstein proposed special relativity in", "correct": ["1905"], "wrong": ["1687", "1915"], "topic": "physics"},
    {"query": "Planck introduced", "correct": ["quantum"], "wrong": ["relativity", "gravity"], "topic": "physics"},
    {"query": "Heisenberg formulated the", "correct": ["uncertainty"], "wrong": ["relativity", "gravity"], "topic": "physics"},
    {"query": "Curie discovered radioactivity in", "correct": ["polonium", "radium"], "wrong": ["uranium", "carbon"], "topic": "physics"},
    {"query": "Bohr proposed the atomic model with", "correct": ["quantized", "electron orbits", "orbits"], "wrong": ["strings", "quarks"], "topic": "physics"},
    {"query": "The photoelectric effect demonstrated the", "correct": ["particle"], "wrong": ["wave", "string"], "topic": "physics"},
    {"query": "Schrodinger developed the", "correct": ["wave equation"], "wrong": ["uncertainty", "periodic table"], "topic": "physics"},

    # Chemistry (8)
    {"query": "Mendeleev created", "correct": ["periodic table"], "wrong": ["atomic bomb", "microscope"], "topic": "chemistry"},
    {"query": "Lavoisier is known as the father of", "correct": ["chemistry"], "wrong": ["physics", "biology"], "topic": "chemistry"},
    {"query": "Dalton proposed the modern", "correct": ["atomic theory"], "wrong": ["periodic table", "quantum"], "topic": "chemistry"},
    {"query": "Pauling discovered the nature of", "correct": ["chemical bonds", "bonds"], "wrong": ["atoms", "gravity"], "topic": "chemistry"},
    {"query": "Water consists of", "correct": ["hydrogen", "oxygen"], "wrong": ["nitrogen", "carbon"], "topic": "chemistry"},
    {"query": "The periodic table was created in", "correct": ["1869"], "wrong": ["1687", "1905", "1953"], "topic": "chemistry"},
    {"query": "Lavoisier discovered the role of oxygen in", "correct": ["combustion"], "wrong": ["photosynthesis", "respiration"], "topic": "chemistry"},
    {"query": "The pH scale measures", "correct": ["hydrogen ion", "ion concentration"], "wrong": ["temperature", "pressure"], "topic": "chemistry"},

    # Cell Biology (8)
    {"query": "The mitochondria is known as the", "correct": ["powerhouse"], "wrong": ["brain", "nucleus"], "topic": "cell_biology"},
    {"query": "Photosynthesis converts sunlight into", "correct": ["chemical energy", "energy"], "wrong": ["heat", "sound"], "topic": "cell_biology"},
    {"query": "Robert Hooke discovered cells in", "correct": ["1665"], "wrong": ["1859", "1953"], "topic": "cell_biology"},
    {"query": "Cellular respiration converts glucose into", "correct": ["atp"], "wrong": ["dna", "protein"], "topic": "cell_biology"},
    {"query": "Ribosomes are responsible for", "correct": ["protein synthesis", "protein"], "wrong": ["dna replication", "cell division"], "topic": "cell_biology"},
    {"query": "The cell membrane consists of", "correct": ["phospholipid", "bilayer"], "wrong": ["protein", "carbohydrate"], "topic": "cell_biology"},
    {"query": "Chloroplasts contain", "correct": ["chlorophyll"], "wrong": ["hemoglobin", "keratin"], "topic": "cell_biology"},
    {"query": "ATP is the energy currency of", "correct": ["cells", "cell"], "wrong": ["atoms", "molecules"], "topic": "cell_biology"},

    # ML (8)
    {"query": "Backpropagation was developed by", "correct": ["hinton"], "wrong": ["einstein", "darwin"], "topic": "ml"},
    {"query": "The attention mechanism was proposed by", "correct": ["vaswani"], "wrong": ["hinton", "lecun"], "topic": "ml"},
    {"query": "LeCun developed", "correct": ["convolutional", "cnn"], "wrong": ["transformer", "gan"], "topic": "ml"},
    {"query": "Goodfellow invented", "correct": ["generative adversarial", "gan"], "wrong": ["transformer", "cnn"], "topic": "ml"},
    {"query": "Transformers use", "correct": ["self-attention", "attention"], "wrong": ["convolution", "recurrence"], "topic": "ml"},
    {"query": "Attention Is All You Need was published in", "correct": ["2017"], "wrong": ["2014", "2012", "2020"], "topic": "ml"},
    {"query": "Support vector machines use", "correct": ["kernel"], "wrong": ["attention", "backpropagation"], "topic": "ml"},
    {"query": "Deep learning uses many layers of", "correct": ["neural networks", "neural"], "wrong": ["decision trees", "linear models"], "topic": "ml"},

    # Astronomy (7)
    {"query": "Galileo discovered the moons of", "correct": ["jupiter"], "wrong": ["saturn", "mars"], "topic": "astronomy"},
    {"query": "Hubble discovered that the universe is", "correct": ["expanding"], "wrong": ["shrinking", "static"], "topic": "astronomy"},
    {"query": "The Big Bang occurred approximately", "correct": ["13.8", "13", "billion"], "wrong": ["4.5", "million"], "topic": "astronomy"},
    {"query": "Hawking proposed that black holes emit", "correct": ["radiation"], "wrong": ["light", "sound"], "topic": "astronomy"},
    {"query": "Kepler formulated the laws of", "correct": ["planetary motion", "planetary"], "wrong": ["gravity", "thermodynamics"], "topic": "astronomy"},
    {"query": "The speed of light is approximately", "correct": ["299792458", "299", "meters per second"], "wrong": ["186000", "miles"], "topic": "astronomy"},
    {"query": "Neutron stars are the densest objects after", "correct": ["black holes"], "wrong": ["white dwarfs", "planets"], "topic": "astronomy"},

    # Cross-domain (4)
    {"query": "Franklin's X-ray images helped discover", "correct": ["dna", "double helix"], "wrong": ["radioactivity", "cells"], "topic": "genetics"},
    {"query": "Newton proposed laws of motion and", "correct": ["gravitation", "gravity"], "wrong": ["evolution", "genetics"], "topic": "physics"},
    {"query": "The endoplasmic reticulum is essential for", "correct": ["protein folding", "lipid synthesis"], "wrong": ["photosynthesis", "respiration"], "topic": "cell_biology"},
    {"query": "Mendeleev predicted", "correct": ["undiscovered elements", "elements"], "wrong": ["evolution", "dna"], "topic": "chemistry"},
]


def score_answer(output: str, correct: list[str], wrong: list[str]) -> tuple[bool, str]:
    """Score a model output against correct/wrong answers."""
    output_lower = output.lower()
    has_correct = any(c.lower() in output_lower for c in correct)
    has_wrong = any(w.lower() in output_lower for w in wrong)
    if has_correct and not has_wrong:
        return True, "correct"
    elif has_correct and has_wrong:
        return True, "correct (with noise)"
    elif has_wrong and not has_correct:
        return False, "wrong"
    else:
        return False, "no answer"
