"""
SEC-RAG Engine — Physics-Navigated Retrieval
=============================================

The core engine. Builds a knowledge graph from your corpus, tracks concept
phases (crystallized/ordered/transitional/chaotic), and uses that to re-rank
retrieved sentences for better LLM context.

No external dependencies beyond sentence-transformers, numpy, and torch.
"""

import json
import math
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np


# ─── Constants (from Dawn Field Theory) ───

XI_SEC = 0.0618      # Structural coupling constant
PHI_INV = 0.618      # Golden ratio inverse
LAMBDA_STAR = 0.9816  # Optimal decay


# ─── Stopwords ───

STOPWORDS = {
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "must", "need",
    "in", "on", "at", "to", "for", "of", "with", "by", "from", "about",
    "into", "through", "during", "before", "after", "above", "below",
    "and", "or", "but", "nor", "not", "so", "yet", "both", "either",
    "that", "which", "who", "whom", "whose", "what", "where", "when",
    "this", "these", "those", "it", "its", "he", "she", "they", "them",
    "his", "her", "their", "my", "your", "our", "i", "we", "you",
    "also", "very", "just", "even", "only", "then", "than", "more",
    "most", "each", "every", "all", "many", "much", "some", "any",
    "no", "if", "as", "up", "out", "how",
}


# ─── Relation Extraction ───

def extract_relations(text: str) -> list[tuple[str, str, str]]:
    """Extract (subject, predicate, object) triples from text."""
    triples = []
    sentences = re.split(r'[.!?]+', text)
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        words = sentence.split()
        if not words:
            continue

        # Find subject (capitalized words at start, or first content word)
        subject_words = []
        for w in words:
            if w[0].isupper() or w.lower() in ("and", "y"):
                subject_words.append(w)
            else:
                break
        if not subject_words:
            for w in words:
                if w.lower() not in STOPWORDS:
                    subject_words = [w]
                    break
        if not subject_words:
            continue
        subject_key = subject_words[-1].lower()
        if not subject_key or subject_key in STOPWORDS:
            subject_key = " ".join(subject_words).lower()

        patterns = [
            (r"(?:proposed|discovered|invented|developed|created|founded|formulated|introduced|demonstrated|proved|showed|established)\s+(?:the\s+)?(.+?)(?:\.|,|$)", "proposed"),
            (r"(?:is|are|was|were)\s+(?:known\s+as|called|named|termed)\s+(?:the\s+)?(.+?)(?:\.|,|$)", "known_as"),
            (r"(?:is|are|was|were)\s+(?:essential|crucial|important|necessary|responsible|used)\s+for\s+(.+?)(?:\.|,|$)", "essential_for"),
            (r"(?:contains?|has|produces?)\s+(?:approximately\s+)?(.+?)(?:\.|,|$)", "has"),
            (r"(?:published|wrote|authored)\s+(.+?)(?:\.|,|$)", "published"),
            (r"(?:uses?|employs?|utilizes?|requires?)\s+(.+?)(?:\.|,|$)", "uses"),
            (r"(?:converts?|transforms?)\s+(.+?)\s+(?:into|to)\s+(.+?)(?:\.|,|$)", "converts"),
            (r"(?:is|are)\s+(?:a|an|the)\s+(\w+(?:\s+\w+){0,3})(?:\.|,|$)", "is_a"),
            (r"(?:acts?\s+on|operates?\s+on|regulates?|controls?)\s+(.+?)(?:\.|,|$)", "acts_on"),
            (r"(?:occurs?\s+in|found\s+in|located\s+in|lives?\s+in)\s+(.+?)(?:\.|,|$)", "found_in"),
            (r"(?:causes?|leads?\s+to|results?\s+in)\s+(.+?)(?:\.|,|$)", "causes"),
            (r"(?:consists?\s+of|composed\s+of|made\s+of)\s+(.+?)(?:\.|,|$)", "consists_of"),
        ]
        for pattern, predicate in patterns:
            for match in re.finditer(pattern, sentence, re.IGNORECASE):
                if predicate == "converts":
                    obj = match.group(2).lower().strip()
                else:
                    obj = match.group(1).lower().strip()
                obj = re.sub(r'^(a|an|the)\s+', '', obj)
                obj = ' '.join(obj.split()[:5])
                if obj and subject_key != obj and subject_key not in STOPWORDS:
                    triples.append((subject_key, predicate, obj))
    return triples


# ─── Concept Node ───

@dataclass
class ConceptNode:
    name: str
    activation_count: int = 0
    outgoing: dict = field(default_factory=lambda: defaultdict(list))
    incoming: dict = field(default_factory=lambda: defaultdict(list))
    cooccurrence: dict = field(default_factory=lambda: defaultdict(int))
    phase: str = "chaotic"
    entropy: float = 1.0

    def update_phase(self):
        total_rels = sum(c for pairs in self.outgoing.values() for _, c in pairs)
        total_rels += sum(c for pairs in self.incoming.values() for _, c in pairs)
        if total_rels < 3:
            self.phase = "chaotic"
            self.entropy = 1.0
            return

        all_counts = []
        for pairs in self.outgoing.values():
            all_counts.extend(c for _, c in pairs)
        for pairs in self.incoming.values():
            all_counts.extend(c for _, c in pairs)
        if not all_counts:
            self.phase = "chaotic"
            self.entropy = 1.0
            return

        total = sum(all_counts)
        probs = [c / total for c in all_counts]
        self.entropy = -sum(p * math.log2(p) for p in probs if p > 0)

        if self.entropy < XI_SEC:
            self.phase = "crystallized"
        elif self.entropy < PHI_INV:
            self.phase = "ordered"
        elif self.entropy < LAMBDA_STAR:
            self.phase = "transitional"
        else:
            self.phase = "chaotic"


# ─── Knowledge Graph ───

class KnowledgeGraph:
    """Knowledge graph with SEC phase tracking.

    Learns from text: extracts concepts, co-occurrence, and relations.
    Each concept gets a phase (crystallized/ordered/transitional/chaotic)
    based on its relational entropy.

    Learning is O(n) in text length, no backprop, no gradients.
    """

    def __init__(self, window: int = 5):
        self.window = window
        self.concepts: dict[str, ConceptNode] = {}
        self.relations: list[tuple[str, str, str, int]] = []
        self.relation_index: dict[tuple[str, str, str], int] = {}
        self.words_processed = 0

    def _tokenize(self, text: str) -> list[str]:
        return re.findall(r"[a-zA-Z]+(?:'[a-zA-Z]+)?|[0-9]+", text.lower())

    def _get_or_create(self, name: str) -> ConceptNode:
        if name not in self.concepts:
            self.concepts[name] = ConceptNode(name=name)
        return self.concepts[name]

    def learn(self, text: str):
        """Learn from text. Call multiple times on same text to strengthen patterns."""
        words = self._tokenize(text)
        for i, word in enumerate(words):
            concept = self._get_or_create(word)
            concept.activation_count += 1
            for j in range(max(0, i - self.window), i):
                other = words[j]
                concept.cooccurrence[other] += 1
                self._get_or_create(other).cooccurrence[word] += 1
            self.words_processed += 1

        for subj, pred, obj in extract_relations(text):
            key = (subj, pred, obj)
            if key in self.relation_index:
                idx = self.relation_index[key]
                s, p, o, c = self.relations[idx]
                self.relations[idx] = (s, p, o, c + 1)
            else:
                self.relation_index[key] = len(self.relations)
                self.relations.append((subj, pred, obj, 1))

            subj_node = self._get_or_create(subj)
            obj_node = self._get_or_create(obj)
            self._add_link(subj_node.outgoing, pred, obj)
            self._add_link(obj_node.incoming, pred, subj)

        for concept in self.concepts.values():
            concept.update_phase()

    def _add_link(self, links: dict, predicate: str, target: str):
        for i, (t, c) in enumerate(links[predicate]):
            if t == target:
                links[predicate][i] = (t, c + 1)
                return
        links[predicate].append((target, 1))

    def query_relations(self, concept: str) -> list[tuple[str, str, str, int]]:
        """Get all relations involving a concept."""
        results = []
        concept_lower = concept.lower()
        matching = [concept_lower]
        for name in self.concepts:
            if concept_lower in name or name in concept_lower:
                if name not in matching:
                    matching.append(name)

        for name in matching:
            if name not in self.concepts:
                continue
            node = self.concepts[name]
            for pred, pairs in node.outgoing.items():
                for obj, count in pairs:
                    results.append((name, pred, obj, count))
            for pred, pairs in node.incoming.items():
                for subj, count in pairs:
                    results.append((subj, pred, name, count))
        results.sort(key=lambda x: -x[3])
        return results

    def get_phase(self, word: str) -> str:
        if word in self.concepts:
            return self.concepts[word].phase
        return "unknown"

    def sec_rerank(self, candidates: list[tuple[str, float]]) -> list[tuple[str, float]]:
        """Re-rank retrieved sentences using SEC phase knowledge."""
        reranked = []
        for sentence, score in candidates:
            words = self._tokenize(sentence)
            phase_scores = []
            rel_bonus = 0.0
            for word in words:
                if word in self.concepts and word not in STOPWORDS:
                    node = self.concepts[word]
                    phase_weight = {
                        "crystallized": 2.0,
                        "ordered": 1.0,
                        "transitional": 0.3,
                        "chaotic": 0.1,
                    }.get(node.phase, 0.5)
                    phase_scores.append(phase_weight)
                    n_rels = sum(len(pairs) for pairs in node.outgoing.values())
                    if n_rels > 0:
                        rel_bonus += 0.2 * min(n_rels, 5)

            phase_weight = sum(phase_scores) / len(phase_scores) if phase_scores else 0.5
            combined = score * phase_weight * (1.0 + rel_bonus)
            reranked.append((sentence, combined))

        reranked.sort(key=lambda x: -x[1])
        return reranked

    def format_relational_context(self, query: str) -> str:
        """Format known relational facts for a query."""
        words = self._tokenize(query)
        content_words = [w for w in words if w not in STOPWORDS]
        if not content_words:
            content_words = words[:3]

        all_rels = []
        for word in content_words:
            all_rels.extend(self.query_relations(word))

        seen = set()
        unique = []
        for r in all_rels:
            key = (r[0], r[1], r[2])
            if key not in seen:
                seen.add(key)
                unique.append(r)
        unique.sort(key=lambda x: -x[3])

        pred_map = {
            "is_a": "is", "proposed": "proposed", "has": "has",
            "essential_for": "is essential for", "causes": "causes",
            "uses": "uses", "known_as": "is known as",
            "acts_on": "acts on", "found_in": "is found in",
            "consists_of": "consists of", "published": "published",
            "converts": "converts to",
        }
        facts = []
        for subj, pred, obj, _ in unique[:6]:
            verb = pred_map.get(pred, pred)
            facts.append(f"{subj} {verb} {obj}")

        return ". ".join(facts) if facts else ""

    def dominant_phase(self, query: str) -> str:
        """Get the dominant SEC phase for a query's concepts."""
        words = self._tokenize(query)
        phases = [self.concepts[w].phase for w in words
                  if w in self.concepts and w not in STOPWORDS]
        if not phases:
            return "unknown"
        return Counter(phases).most_common(1)[0][0]

    def stats(self) -> dict:
        n_concepts = len(self.concepts)
        n_relations = len(self.relations)
        phases = defaultdict(int)
        for c in self.concepts.values():
            phases[c.phase] += 1
        return {
            "concepts": n_concepts,
            "relations": n_relations,
            "words_processed": self.words_processed,
            "crystallized": phases["crystallized"],
            "ordered": phases["ordered"],
            "transitional": phases["transitional"],
            "chaotic": phases["chaotic"],
        }

    # ─── Persistence ───

    def save(self, path: str):
        """Save the knowledge graph to a JSON file.

        The graph persists across sessions — load it back and it keeps
        compounding from where it left off. No retraining needed.
        """
        data = {
            "version": 1,
            "window": self.window,
            "words_processed": self.words_processed,
            "relations": self.relations,
            "concepts": {},
        }
        for name, node in self.concepts.items():
            data["concepts"][name] = {
                "activation_count": node.activation_count,
                "phase": node.phase,
                "entropy": node.entropy,
                "outgoing": {k: v for k, v in node.outgoing.items()},
                "incoming": {k: v for k, v in node.incoming.items()},
                "cooccurrence": dict(node.cooccurrence),
            }
        with open(path, "w") as f:
            json.dump(data, f)
        print(f"  Graph saved: {path} ({len(self.concepts)} concepts, "
              f"{len(self.relations)} relations)")

    @classmethod
    def load(cls, path: str) -> "KnowledgeGraph":
        """Load a knowledge graph from a JSON file."""
        with open(path) as f:
            data = json.load(f)
        graph = cls(window=data.get("window", 5))
        graph.words_processed = data.get("words_processed", 0)
        graph.relations = [tuple(r) for r in data.get("relations", [])]
        graph.relation_index = {
            (r[0], r[1], r[2]): i for i, r in enumerate(graph.relations)
        }
        for name, cdata in data.get("concepts", {}).items():
            node = ConceptNode(name=name)
            node.activation_count = cdata["activation_count"]
            node.phase = cdata["phase"]
            node.entropy = cdata["entropy"]
            for pred, pairs in cdata.get("outgoing", {}).items():
                node.outgoing[pred] = [tuple(p) for p in pairs]
            for pred, pairs in cdata.get("incoming", {}).items():
                node.incoming[pred] = [tuple(p) for p in pairs]
            node.cooccurrence = defaultdict(int, cdata.get("cooccurrence", {}))
            graph.concepts[name] = node
        print(f"  Graph loaded: {path} ({len(graph.concepts)} concepts, "
              f"{len(graph.relations)} relations)")
        return graph

    # ─── Curriculum Optimizer ───

    def analyze_transfer(self, domains: dict[str, str]) -> dict:
        """Analyze which domain order maximizes learning transfer.

        Builds a temporary graph for each domain, measures how many
        cross-domain relational bridges each one creates. Domains that
        bridge to many others should be learned first (hub domains).

        Returns:
            {
                "recommended_order": ["ml", "physics", ...],
                "domain_scores": {"ml": 0.85, ...},
                "transfer_matrix": {"ml": {"physics": 0.3, ...}, ...},
            }
        """
        domain_names = list(domains.keys())
        n = len(domain_names)

        # Build per-domain concept sets
        domain_concepts = {}
        for name, text in domains.items():
            words = self._tokenize(text)
            domain_concepts[name] = {w for w in words if w not in STOPWORDS}

        # Compute pairwise overlap (shared concepts = transfer potential)
        transfer_matrix = {}
        hub_scores = {}
        for src in domain_names:
            transfer_matrix[src] = {}
            total_transfer = 0
            for dst in domain_names:
                if src == dst:
                    transfer_matrix[src][dst] = 0.0
                    continue
                shared = domain_concepts[src] & domain_concepts[dst]
                # Jaccard similarity weighted by concept count
                union = domain_concepts[src] | domain_concepts[dst]
                overlap = len(shared) / len(union) if union else 0
                transfer_matrix[src][dst] = round(overlap, 3)
                total_transfer += overlap
            hub_scores[src] = round(total_transfer / (n - 1), 3) if n > 1 else 0

        # Build relational bridge score (domains with more extractable relations)
        rel_scores = {}
        for name, text in domains.items():
            rels = extract_relations(text)
            # Relations that reference concepts from OTHER domains
            bridge_count = 0
            for subj, pred, obj in rels:
                for other_name, other_concepts in domain_concepts.items():
                    if other_name != name:
                        if subj in other_concepts or obj in other_concepts:
                            bridge_count += 1
                            break
            rel_scores[name] = bridge_count

        # Combined score: hub_score * 0.6 + relational_bridges * 0.4
        combined = {}
        max_rels = max(rel_scores.values()) if rel_scores else 1
        for name in domain_names:
            rel_norm = rel_scores[name] / max_rels if max_rels > 0 else 0
            combined[name] = round(hub_scores[name] * 0.6 + rel_norm * 0.4, 3)

        # Sort by combined score (highest first = learn first)
        recommended = sorted(domain_names, key=lambda d: -combined[d])

        return {
            "recommended_order": recommended,
            "domain_scores": combined,
            "hub_scores": hub_scores,
            "relational_bridges": rel_scores,
            "transfer_matrix": transfer_matrix,
        }

    # ─── Graph Export (for embedding grafting) ───

    def export_portable(self) -> dict:
        """Export graph in a model-agnostic format for grafting.

        The exported graph contains only the structural knowledge:
        concepts, relations, phases, and co-occurrence counts.
        No model-specific data. Can be loaded into any SEC-RAG instance
        regardless of which LLM or embedding model is being used.

        This is embedding grafting — transfer knowledge between models
        without any retraining. Validated at 100% transfer in POC-020.
        """
        return {
            "format": "sec-rag-portable-v1",
            "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "stats": self.stats(),
            "concepts": {
                name: {
                    "activation_count": node.activation_count,
                    "phase": node.phase,
                    "entropy": node.entropy,
                    "outgoing": dict(node.outgoing),
                    "incoming": dict(node.incoming),
                    "top_cooccurrences": dict(
                        sorted(node.cooccurrence.items(), key=lambda x: -x[1])[:20]
                    ),
                }
                for name, node in self.concepts.items()
                if node.activation_count > 2  # skip noise
            },
            "relations": [
                {"subject": s, "predicate": p, "object": o, "count": c}
                for s, p, o, c in self.relations if c > 1  # skip noise
            ],
        }

    def import_portable(self, data: dict):
        """Import a portable graph exported from another SEC-RAG instance.

        Merges into the current graph — concepts get combined, relations
        get summed. This is the grafting operation.
        """
        if data.get("format") != "sec-rag-portable-v1":
            raise ValueError("Unknown graph format. Expected sec-rag-portable-v1.")

        imported_concepts = 0
        imported_relations = 0

        for name, cdata in data.get("concepts", {}).items():
            node = self._get_or_create(name)
            node.activation_count += cdata.get("activation_count", 0)
            for pred, pairs in cdata.get("outgoing", {}).items():
                for target, count in pairs:
                    self._add_link(node.outgoing, pred, target)
            for pred, pairs in cdata.get("incoming", {}).items():
                for source, count in pairs:
                    self._add_link(node.incoming, pred, source)
            for other, count in cdata.get("top_cooccurrences", {}).items():
                node.cooccurrence[other] += count
            imported_concepts += 1

        for rel in data.get("relations", []):
            key = (rel["subject"], rel["predicate"], rel["object"])
            if key in self.relation_index:
                idx = self.relation_index[key]
                s, p, o, c = self.relations[idx]
                self.relations[idx] = (s, p, o, c + rel["count"])
            else:
                self.relation_index[key] = len(self.relations)
                self.relations.append((key[0], key[1], key[2], rel["count"]))
            imported_relations += 1

        # Recalculate phases
        for node in self.concepts.values():
            node.update_phase()

        print(f"  Grafted: {imported_concepts} concepts, {imported_relations} relations")


# ─── Embedding Index ───

class EmbeddingIndex:
    """Sentence-level semantic retrieval using sentence-transformers."""

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        print(f"Loading embedding model ({model_name})...")
        self.model = SentenceTransformer(model_name)
        self.sentences: list[str] = []
        self.embeddings: np.ndarray = None

    def index(self, corpus: str):
        """Split corpus into sentences and compute embeddings."""
        raw = re.split(r'[.!?]+', corpus)
        self.sentences = [s.strip() for s in raw if len(s.strip()) > 20]
        print(f"  Indexed {len(self.sentences)} sentences")
        self.embeddings = self.model.encode(self.sentences, normalize_embeddings=True)

    def retrieve(self, query: str, top_k: int = 5) -> list[tuple[str, float]]:
        """Retrieve top-k sentences by cosine similarity."""
        q_emb = self.model.encode([query], normalize_embeddings=True)
        scores = np.dot(self.embeddings, q_emb.T).flatten()
        top_idx = np.argsort(scores)[::-1][:top_k]
        return [(self.sentences[i], float(scores[i])) for i in top_idx]


# ─── SEC-RAG Pipeline ───

class SECRAGPipeline:
    """SEC-navigated Retrieval-Augmented Generation.

    Usage:
        pipeline = SECRAGPipeline(server)
        pipeline.ingest("Your corpus text here...")
        answer = pipeline.query("What is X?")
    """

    def __init__(self, server, embedding_model: str = "all-MiniLM-L6-v2"):
        self.server = server
        self.graph = KnowledgeGraph(window=5)
        self.index = EmbeddingIndex(embedding_model)
        self._corpus_indexed = False

    def ingest(self, corpus: str, n_passes: int = 5):
        """Ingest corpus into embedding index + knowledge graph."""
        if not self._corpus_indexed:
            self.index.index(corpus)
            self._corpus_indexed = True

        for _ in range(n_passes):
            self.graph.learn(corpus)

        stats = self.graph.stats()
        print(f"  Graph: {stats['concepts']} concepts, {stats['relations']} relations, "
              f"{stats['crystallized']} crystallized")

    def query(self, question: str, method: str = "sec_rag",
              max_tokens: int = 60, temperature: float = 0.7) -> str:
        """Ask a question. Methods: 'raw', 'rag', 'sec_rag'."""
        if method == "raw":
            return self.server.generate(question, max_tokens=max_tokens,
                                         temperature=temperature).text

        elif method == "rag":
            results = self.index.retrieve(question, top_k=3)
            context = ". ".join(s for s, _ in results) + "."
            prompt = f"Based on the following information: {context}\n\n{question}"
            return self.server.generate(prompt, max_tokens=max_tokens,
                                         temperature=temperature).text

        elif method == "sec_rag":
            # Get relational facts from knowledge graph
            rel_context = self.graph.format_relational_context(question)
            phase = self.graph.dominant_phase(question)

            # Retrieve and SEC-rerank
            candidates = self.index.retrieve(question, top_k=6)
            reranked = self.graph.sec_rerank(candidates)

            # Phase-gated context sizing (fixed: less aggressive)
            if phase == "crystallized":
                n_retrieve = 2   # confident: focused context
            elif phase in ("ordered", "unknown"):
                n_retrieve = 3   # moderate: balanced
            else:
                n_retrieve = 4   # uncertain: broad coverage

            top_sentences = [s for s, _ in reranked[:n_retrieve]]

            parts = []
            if rel_context:
                parts.append(f"Known facts: {rel_context}")
            if top_sentences:
                parts.append(f"Reference: {'. '.join(top_sentences)}")

            if not parts:
                # Fallback to standard RAG
                return self.query(question, method="rag",
                                  max_tokens=max_tokens, temperature=temperature)

            context = ". ".join(parts) + "."
            prompt = f"{context}\n\n{question}"
            return self.server.generate(prompt, max_tokens=max_tokens,
                                         temperature=temperature).text

        else:
            raise ValueError(f"Unknown method: {method}. Use 'raw', 'rag', or 'sec_rag'.")

    def learn_from_query(self, question: str, response: str):
        """Learn from a query-response pair (continuous learning)."""
        self.graph.learn(f"{question} {response}")
