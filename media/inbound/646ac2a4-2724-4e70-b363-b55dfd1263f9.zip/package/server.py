"""
Local Model Server — Unified interface for local LLM inference.

Supports:
  - HuggingFace transformers (any model on the hub)
  - llama-cpp-python (GGUF quantized models — recommended for big models)

The server auto-detects which backend to use based on the model path.
"""

import time
from dataclasses import dataclass, field
from pathlib import Path

import torch


@dataclass
class GenerationResult:
    """Result from a generation call."""
    text: str
    full_text: str
    prompt: str
    tokens_generated: int = 0
    tokens_per_second: float = 0.0
    latency_ms: float = 0.0
    hidden_states: torch.Tensor = None
    logprobs: list[float] = field(default_factory=list)


class LocalModelServer:
    """Unified local LLM server.

    Usage:
        server = LocalModelServer("Qwen/Qwen2.5-0.5B")  # HuggingFace
        server = LocalModelServer("/path/to/model.gguf")  # GGUF

        result = server.generate("The capital of France is", max_tokens=20)
        print(result.text)
    """

    def __init__(self, model_id: str, backend: str = "auto", device: str = "auto",
                 max_context: int = 2048, n_gpu_layers: int = -1):
        """
        Args:
            model_id: HuggingFace model ID or path to GGUF file
            backend: "transformers", "llama_cpp", or "auto"
            device: "cpu", "cuda", or "auto"
            max_context: Maximum context length
            n_gpu_layers: For llama.cpp: layers to offload to GPU (-1 = all)
        """
        self.model_id = model_id
        self.max_context = max_context
        self.n_gpu_layers = n_gpu_layers

        if backend == "auto":
            if model_id.endswith(".gguf") or Path(model_id).suffix == ".gguf":
                backend = "llama_cpp"
            else:
                backend = "transformers"

        self.backend = backend

        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = device

        if backend == "transformers":
            self._load_transformers(model_id)
        elif backend == "llama_cpp":
            self._load_llama_cpp(model_id)
        else:
            raise ValueError(f"Unknown backend: {backend}")

    def _load_transformers(self, model_id: str):
        from transformers import AutoModelForCausalLM, AutoTokenizer

        print(f"Loading {model_id} via transformers on {self.device}...")
        t0 = time.time()

        self.tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        dtype = torch.float16 if self.device == "cuda" else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id, torch_dtype=dtype, trust_remote_code=True,
            device_map=self.device if self.device == "cuda" else None,
        )
        if self.device == "cpu":
            self.model = self.model.to(self.device)
        self.model.eval()

        n_params = sum(p.numel() for p in self.model.parameters())
        n_layers = getattr(self.model.config, "num_hidden_layers", "?")
        hidden_dim = getattr(self.model.config, "hidden_size", "?")
        load_time = time.time() - t0
        mem_mb = n_params * (2 if dtype == torch.float16 else 4) / 1e6

        print(f"  Loaded: {n_params/1e6:.0f}M params, {n_layers} layers, "
              f"dim={hidden_dim}, ~{mem_mb:.0f}MB")
        print(f"  Load time: {load_time:.1f}s")

    def _load_llama_cpp(self, model_path: str):
        try:
            from llama_cpp import Llama
        except ImportError:
            raise ImportError(
                "llama-cpp-python not installed. Install with:\n"
                "  pip install llama-cpp-python\n"
                "For CUDA: CMAKE_ARGS=\"-DGGML_CUDA=on\" pip install llama-cpp-python --force-reinstall"
            )

        print(f"Loading {Path(model_path).name} via llama.cpp...")
        t0 = time.time()

        self.llama = Llama(
            model_path=model_path,
            n_ctx=self.max_context,
            n_gpu_layers=self.n_gpu_layers,
            verbose=False,
        )

        load_time = time.time() - t0
        print(f"  Load time: {load_time:.1f}s")

    @torch.no_grad()
    def generate(self, prompt: str, max_tokens: int = 60,
                 temperature: float = 0.7, top_k: int = 50, top_p: float = 0.9,
                 return_hidden_states: bool = False) -> GenerationResult:
        """Generate text from a prompt."""
        if self.backend == "transformers":
            return self._gen_transformers(prompt, max_tokens, temperature,
                                           top_k, top_p, return_hidden_states)
        else:
            return self._gen_llama_cpp(prompt, max_tokens, temperature, top_k, top_p)

    def _gen_transformers(self, prompt, max_tokens, temperature,
                           top_k, top_p, return_hidden_states):
        input_ids = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)
        prompt_len = input_ids.shape[1]

        t0 = time.time()
        gen_kwargs = dict(
            max_new_tokens=max_tokens,
            temperature=max(temperature, 1e-7),
            top_k=top_k, top_p=top_p,
            do_sample=temperature > 0,
            pad_token_id=self.tokenizer.eos_token_id,
            output_hidden_states=return_hidden_states,
            return_dict_in_generate=return_hidden_states,
        )
        outputs = self.model.generate(input_ids, **gen_kwargs)
        elapsed = time.time() - t0

        if return_hidden_states:
            output_ids = outputs.sequences[0]
        else:
            output_ids = outputs[0]

        n_generated = len(output_ids) - prompt_len
        full_text = self.tokenizer.decode(output_ids, skip_special_tokens=True)
        completion = self.tokenizer.decode(output_ids[prompt_len:], skip_special_tokens=True)

        hidden = None
        if return_hidden_states and hasattr(outputs, "hidden_states") and outputs.hidden_states:
            first_step = outputs.hidden_states[0]
            hidden = torch.stack([h.squeeze(0) for h in first_step])

        tps = n_generated / elapsed if elapsed > 0 else 0
        return GenerationResult(
            text=completion, full_text=full_text, prompt=prompt,
            tokens_generated=n_generated, tokens_per_second=tps,
            latency_ms=elapsed * 1000, hidden_states=hidden,
        )

    def _gen_llama_cpp(self, prompt, max_tokens, temperature, top_k, top_p):
        t0 = time.time()
        output = self.llama(
            prompt, max_tokens=max_tokens,
            temperature=temperature, top_k=top_k, top_p=top_p,
        )
        elapsed = time.time() - t0

        completion = output["choices"][0]["text"]
        n_tokens = output["usage"]["completion_tokens"]
        tps = n_tokens / elapsed if elapsed > 0 else 0

        return GenerationResult(
            text=completion, full_text=prompt + completion, prompt=prompt,
            tokens_generated=n_tokens, tokens_per_second=tps,
            latency_ms=elapsed * 1000,
        )

    def info(self) -> dict:
        info = {"model_id": self.model_id, "backend": self.backend, "device": self.device}
        if self.backend == "transformers":
            info["n_params"] = sum(p.numel() for p in self.model.parameters())
            info["n_layers"] = getattr(self.model.config, "num_hidden_layers", None)
            info["hidden_dim"] = getattr(self.model.config, "hidden_size", None)
        return info
